package com.syachan.mvvmnewsapp.model

class NewsResponse(
    val article: MutableList<Article>,
    val status: String,
    val totalResult: Int
)