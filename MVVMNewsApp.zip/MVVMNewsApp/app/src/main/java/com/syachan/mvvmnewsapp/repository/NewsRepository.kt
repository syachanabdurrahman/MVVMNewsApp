package com.syachan.mvvmnewsapp.repository

import com.syachan.mvvmnewsapp.database.ArticleDatabse
import com.syachan.mvvmnewsapp.network.RetrofitInstance

class NewsRepository(val db : ArticleDatabse) {

    suspend fun getBreakingNews(countryCode: String, pageNumber: Int) =
        RetrofitInstance.api.getBreakingNews(countryCode, pageNumber)

    suspend fun searchNews(searchQuery: String, pageNumber: Int) =
        RetrofitInstance.api.searchNews(searchQuery, pageNumber)

    


}