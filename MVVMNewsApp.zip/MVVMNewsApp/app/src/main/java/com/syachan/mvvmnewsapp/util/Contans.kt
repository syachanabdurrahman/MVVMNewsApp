package com.syachan.mvvmnewsapp.util

class Contans {
    companion object{
        const val API_KEY = "0538592e6b434954bfea020e2787d7aa"
        const val BASE_URL = "https://newsapi.org/"
        const val QUERY_PAGE_SIZE = 20
    }
}