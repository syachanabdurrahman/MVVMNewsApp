package com.syachan.mvvmnewsapp.model

class Source(
    val id: Any,
    val name: String
)