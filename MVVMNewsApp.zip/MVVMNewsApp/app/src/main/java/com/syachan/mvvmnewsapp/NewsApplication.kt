package com.syachan.mvvmnewsapp

import android.app.Application

class NewsApplication : Application()